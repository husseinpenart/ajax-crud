<?php 


include 'db.php';
$id = $_POST['id'];
$username = $_POST['username'];
$password = $_POST['password'];
$result  = $conn->prepare("UPDATE  FROM user SET username=?, password=? WHERE id=?");
$result->bindValue(1,$username);
$result->bindValue(2,$password);
$result->bindValue(3,$id);
$result->execute();
//$results = $result->fetch(PDO::FETCH_ASSOC);
//$json = json_encode($results);
//echo $json;
?>
