<?php
include './db.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css
 " />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
                integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
                crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
                integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF"
                crossorigin="anonymous"></script>

            <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ajaxy/1.6.1/scripts/jquery.ajaxy.min.js" integrity="sha512-bztGAvCE/3+a1Oh0gUro7BHukf6v7zpzrAb3ReWAVrt+bVNNphcl2tDTKCBr5zk7iEDmQ2Bv401fX3jeVXGIcA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ajaxy/1.6.1/scripts/jquery.ajaxy.js" integrity="sha512-4WpSQe8XU6Djt8IPJMGD9Xx9KuYsVCEeitZfMhPi8xdYlVA5hzRitm0Nt1g2AZFS136s29Nq4E4NVvouVAVrBw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="./style.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Document</title>
</head>
<body>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary m-3" data-bs-toggle="modal" data-bs-target="#exampleModal" id="open-modal">
  add user
</button>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">add new user</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post" id="user-form">
          <input type="hidden" id="user-id">
            <input type="text" id="username" class="form-control" placeholder="username">
            <span style="font-size:12px" id="alert-username" class="text-danger"> </span>
            <br>
            <input type="password" id="password" class="form-control" placeholder="password">
            <span id="alert-password" class="text-danger" style="font-size:12px"></span>
            <br>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button"  class="btn btn-primary" id="send-request">Save changes</button>
        <button type="button"  class="btn btn-warning" id="update-request" style="display:none">update request </button>
      </div>
    </div>
  </div>
</div>



<hr class="hr hr-blurry">

<table class="table table-striped table-responsive">
  <thead>

  </thead>
  <tbody id="list-users">


  </tbody>
</table>

<button class="btn btn-info m-3" id="refresh">refresh</button>






<script>

  $(document).ready(function (){
    // reset form automatic
$("#open-modal").click(function(){
   $("#user-form")[0].reset()
   $("#user-id").val("")
   $("#username").val("")
   $("#password").val("")

  $("#username").css("border", "1px solid #ced4da")
  $("#password").css("border", "1px solid #ced4da")


  $("#alert-username").html("")
  $("#alert-password").html("")

// reset button
  $("#update-request").hide()
         $("#send-request").show()

})
    // reset form automatic
   // first fetch data ajax
   $.ajax({
  url: "fetch.php",
  method: "POST",
  success: function (values) {
    $("#list-users").html(values)
  }
});
$("#refresh").click(function(){
  $.ajax({
  url: "fetch.php",
  method: "POST",
  success: function (values) {
    $("#list-users").html(values)
  }
});
})
   // first fetch data ajax

            // empty field validate

    $("#send-request").click(function(){
      var username = $("#username").val()
      var password = $("#password").val()
      var passlen = password.length
      // empty field validate
  //  send ajax request (data)
  if (username !== '' && password !== '' && passlen > "0" && passlen >= "8"){
     $.ajax({
      url:"insert.php",
      method:"POST",
      data:{username:username ,password:password},
      success:function(){
        Swal.fire(
  'Good job!',
  'successfully deleted',
  'success'
)
        // fetch alive
        $.ajax({
      url:"fetch.php",
      method:"POST",
      success:function(values){
        $("#list-users").html(values)
      }
     })
      }
     })

  }
  //  send ajax request (data)
      if (username == ''){
       $("#username").css("border", "1px solid red")
       $("#alert-username").html("this  field is required")
      }
      if (password == ''){
        $("#password").css("border" , "1px solid red")
        $("#alert-password").html("this  field is required")

      }

// success validate
      if (username !== ''){
       $("#username").css("border", "1px solid green")
       $("#alert-username").html("excellent u are filling the fields")
      }
      if (password !== ''){


        $("#password").css("border" , "1px solid green")
        $("#alert-password").html("excellent u are filling the fields")

      }
      if(passlen> "0" && passlen < "8"){
          $("#password").css("border" , "1px solid red")
          $("#alert-password").html("at least 8 character")
        }
    })
    // delete data
    $(document).on('click', '#delete-user', function () {
      var id = $(this).val()
      $.ajax({
        url:"delete.php",
        method:"POST",
        data:{id:id},
        success:function(){
Swal.fire(
  'Good job!',
  'successfully deleted',
  'success'
)
// live load
  // fetch alive
  $.ajax({
      url:"fetch.php",
      method:"POST",
      success:function(values){
        $("#list-users").html(values)
      }
     })

        }
      })
     })
    // delete data


    // update data in users

    $(document).on('click','#edit-user',function(){
      var id = $(this).val();
      $("#user-form")[0].reset()
      $("#username").css("border", "1px solid #ced4da")
  $("#password").css("border", "1px solid #ced4da")

  $("#alert-username").html("")
  $("#alert-password").html("")
      $.ajax({
        url: "fetchRow.php",
        method:"POST",
        data: {id:id},

        success: function (values) {
        var data = jQuery.parseJSON(values)
         $("#user-id").val(data.id)
         $("#username").val(data.username)
         $("#password").val(data.password)
         $("#update-request").show()
         $("#send-request").hide()
        }
      });
    })
  $("#update-request").click(function(){
    var id = $("#user-id").val()
    var username = $("#username").val()
    var passsword = $("#passsword").val()
   $.ajax({
    url:"update.php",
    method:"POST",
    data:{id:id,username:username, password:password},
    success:function (){
      Swal.fire(
  'Good job!',
  'successfully updated',
  'success'
)
 // fetch alive
 $.ajax({
      url:"fetch.php",
      method:"POST",
      success:function(values){
        $("#list-users").html(values)
      }
     })

    }
   })

  })


    // update data in users
  })

</script>


















<script type="text/javascript">
//modal auto load
  $(window).on('load', function() {
    // $('#exampleModal').modal('show');
  });



</script>













































</body>
</html>
