<?php
include 'db.php';
$id = $_POST['id'];
$result = $conn->prepare("DELETE FROM `user` WHERE id=?");
$result->bindValue(1,$id);
$result->execute();

?>