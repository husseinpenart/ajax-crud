<?php 
include 'db.php';
$num = 1;
$result  = $conn->prepare("SELECT * FROM user ");
$result->execute();
$results = $result->fetchAll(PDO::FETCH_ASSOC);


?>


<table class="table table-striped table-responsive">
  <thead>
    <tr>
      <th>row</th>
      <th>username</th>
      <th>password</th>
      <th>operation</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($results as $row){ ?>
    <tr>
      <td><?= $num++?></td>
      <td><?= $row['username']?></td>
      <td><?= $row['password']?></td>

      <td>
        <button class="btn btn-warning" id="edit-user" value="<?= $row['id']?>"  data-bs-toggle="modal" data-bs-target="#exampleModal">edit</button>
        <button class="btn btn-danger" id="delete-user" value="<?= $row['id']?>">delete</button>
      </td>
    </tr>
    <?php } ?>

  </tbody>
</table>